﻿#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <cmath>

using namespace std;

// --- GLOBAL ENUMS & STRUCTS ---

enum GameState {
    STATE_INTRO,    // Orange Page + Loading Page
    STATE_MENU,     // Main Menu Page
    STATE_SETTINGS, // Settings Page
    STATE_LEVELS,   // Level Selection Page
    STATE_LEVEL1,   // Actual Game Play
    STATE_WIN,      // Display Congratulations (3 Stars Achieved)
    STATE_FAIL      // <-- NEW: Display Oops/Replay (Moves Finished, < 3 Stars)
};

// State machine for handling match-3 sequence animations (We'll use a simple version)
enum GameLogicState { 
    LOGIC_IDLE, LOGIC_SWAPPING, LOGIC_CHECKING, LOGIC_FALLING, LOGIC_REFILLING
};

enum CandyType { TYPE_1, TYPE_2, TYPE_3, TYPE_4, TYPE_5, TYPE_EMPTY = 99 };
struct Candy {
    CandyType type = TYPE_EMPTY;
};

// --- GLOBAL GAME DATA (SFML & Logic Variables Combined) ---

// SFML State Variables
GameState gameState = STATE_INTRO;
GameLogicState logicState = LOGIC_IDLE;
const int MAX_GRID_SIZE = 9; // Max grid size defined by the SFML implementation (Level 9/10 use 9x9 in the SFML code)
Candy level1Candies[MAX_GRID_SIZE][MAX_GRID_SIZE]; // Main board for drawing
int matched[MAX_GRID_SIZE][MAX_GRID_SIZE]; // Temporary match marker

sf::Texture candyTextures[5];
sf::Font mainFont;

// Game Logic Variables (From the second code block)
int currentLevel = 1;
int maxUnlockedLevel = 1;
int lives = 3;
int volume = 5;
bool isMuted = false;
int totalStars = 0;
int levelStars[15] = { 0 }; // Adjusted to match the logic size
int currentlivestars = 0;
int score = 0;
int currentMoves = 0;

// Swap tracking for mouse/input
int selectedR = -1; int selectedC = -1;
int secondR = -1; int secondC = -1;
bool swapRequested = false;

// Time tracking for Intro/Loading screens
sf::Clock transitionClock;
const float INTRO_DISPLAY_TIME = 2.0f;
const float FADE_OUT_TIME = 0.5f;
const float LOADING_SHOW_TIME = 3.0f;
// NEW Win/Fail State Timer
sf::Clock endLevelClock;
const float END_LEVEL_SCREEN_DURATION = 3.0f; 


// Volume slider state
float volumeValue = 0.5f;
float previousVolumeValue = volumeValue;
bool volumeEnabled = true;

// Score thresholds per level (Adjusted to match 0-indexed C++ array for easy access)
int scorethreshold[10][3] = {
    {10000,15000,20000},    // LEVEL 1 (index 0)
    {12000,18000,30000},    // LEVEL 2 (index 1)
    {14000,24000,45000},    // LEVEL 3 (index 2)
    {16000,30000,60000},    // LEVEL 4 (index 3)
    {18000,38000,70000},    // LEVEL 5 (index 4)
    {20000,45000,75000},    // LEVEL 6 (index 5)
    {22000,55000,80000},    // LEVEL 7 (index 6)
    {24000,60000,85000},    // LEVEL 8 (index 7)
    {26000,75000,90000},    // LEVEL 9 (index 8)
    {50000,80000,1000000} // LEVEL 10 (index 9)
};

// --- GAME LOGIC FUNCTIONS (Adapted for Candy struct) ---

int getGridSize(int level) {
    if (level == 1 || level == 2) return 5;
    if (level == 3 || level == 4) return 6;
    if (level == 5 || level == 6) return 7;
    if (level == 7 || level == 8) return 8;
    // Note: SFML drawing logic only supports up to 9x9 due to array declaration.
    if (level == 9 || level == 10) return 9; 
    return 0;
}

int getLevelMoves(int level)
{
    if (level == 1 || level == 2) return 20;
    if (level == 3 || level == 4) return 18;
    if (level == 5 || level == 6) return 15;
    if (level == 7 || level == 8) return 12;
    if (level == 9 || level == 10) return 10;
    return 0;
}

int calculateStars(int score, int currentLevel) {
    if (currentLevel < 1 || currentLevel > 10) return 0;
    int index = currentLevel - 1;
    int first = scorethreshold[index][0];
    int second = scorethreshold[index][1];
    int third = scorethreshold[index][2];

    if (score >= third) return 3;
    else if (score >= second) return 2;
    else if (score >= first) return 1;
    else return 0;
}

void updateStars() {
    currentlivestars = calculateStars(score, currentLevel);
}

// MODIFIED: Level is only 'passed' if 3 stars are achieved.
bool isLevelPassedForWin() {
    if (currentLevel < 1 || currentLevel > 10) return false;
    int threeStarScore = scorethreshold[currentLevel - 1][2];
    return score >= threeStarScore;
}

void failLevel() { lives--; }

void completeLevel() {
    int stars = calculateStars(score, currentLevel);
    totalStars -= levelStars[currentLevel - 1];
    levelStars[currentLevel - 1] = stars;
    totalStars += stars;

    if (currentLevel < 10) {
        currentLevel++;
        if (currentLevel > maxUnlockedLevel)
            maxUnlockedLevel = currentLevel;

        if ((currentLevel % 5) == 1) { // Unlock the next 5 levels (e.g., jump from 1 to 6)
            if (maxUnlockedLevel + 5 <= 10)
                maxUnlockedLevel += 5;
        }
    }
}

void playLevel(int gain) {
    // If game has just started (before first move logic)
    if (currentMoves == 0 && score == 0) {
         currentMoves = getLevelMoves(currentLevel);
    }
    
    if (gain < 0) return;

    score += gain;

    updateStars();
    
    // Win condition check: If 3 stars are achieved, end the level immediately.
    if (isLevelPassedForWin()) {
        completeLevel();
        gameState = STATE_WIN;
        endLevelClock.restart();
        return;
    }

    // Lose condition check: If moves hit zero AND we haven't achieved 3 stars.
    if (currentMoves <= 0) { 
        if (!isLevelPassedForWin()) {
            failLevel();
            gameState = STATE_FAIL; // New state transition
            endLevelClock.restart();
        }
        // If 3 stars are achieved *on* the last move, the STATE_WIN block above handles it.
    }
}


// --- CORE MATCH-3 LOGIC (ADAPTED FOR CANDY STRUCT) ---

void GenerateCandyGrid(Candy grid[][MAX_GRID_SIZE], int gridSize, int candyTypes)
{
    // Initialize the whole grid to empty/safe state first (especially if size < MAX_GRID_SIZE)
    for (int i = 0; i < MAX_GRID_SIZE; i++) {
        for (int j = 0; j < MAX_GRID_SIZE; j++) {
            grid[i][j].type = TYPE_EMPTY;
        }
    }

    for (int i = 0; i < gridSize; i++)
    {
        for (int j = 0; j < gridSize; j++)
        {
            do
            {
                grid[i][j].type = (CandyType)(rand() % candyTypes);

            } while (
                // Avoid horizontal match of 3
                (j >= 2 &&
                    grid[i][j].type == grid[i][j - 1].type &&
                    grid[i][j].type == grid[i][j - 2].type) ||

                // Avoid vertical match of 3
                (i >= 2 &&
                    grid[i][j].type == grid[i - 1][j].type &&
                    grid[i][j].type == grid[i - 2][j].type)
                );
        }
    }
    // Set initial moves and reset score for the level start
    currentMoves = getLevelMoves(currentLevel);
    score = 0;
    currentlivestars = 0;
    selectedR = selectedC = secondR = secondC = -1;
}

void restartLevel(int level) {
    currentLevel = level;
    score = 0;
    currentMoves = getLevelMoves(currentLevel);
    currentlivestars = 0;
    
    // Regenerate the grid
    GenerateCandyGrid(level1Candies, getGridSize(currentLevel), 5);
}

int countMatches(int gridSize)
{
    int matchCount = 0;
    // Ensure matched array is clean
    for (int i = 0; i < gridSize; i++) {
        for (int j = 0; j < gridSize; j++) {
            matched[i][j] = 0;
        }
    }

    // Horizontal matches
    for (int i = 0; i < gridSize; i++) {
        for (int j = 0; j <= gridSize - 3; j++) {
            CandyType type = level1Candies[i][j].type;
            if (type != TYPE_EMPTY && 
                type == level1Candies[i][j + 1].type && 
                type == level1Candies[i][j + 2].type) {
                
                for (int k = 0; j + k < gridSize && level1Candies[i][j + k].type == type; k++) {
                     matched[i][j + k] = 1;
                }
            }
        }
    }
    
    // Vertical matches
    for (int j = 0; j < gridSize; j++) {
        for (int i = 0; i <= gridSize - 3; i++) {
            CandyType type = level1Candies[i][j].type;
            if (type != TYPE_EMPTY && 
                type == level1Candies[i + 1][j].type && 
                type == level1Candies[i + 2][j].type) {
                
                for (int k = 0; i + k < gridSize && level1Candies[i + k][j].type == type; k++) {
                    matched[i + k][j] = 1;
                }
            }
        }
    }
    
    // Count unique matches marked as 1
    matchCount = 0;
    for (int i = 0; i < gridSize; i++) {
        for (int j = 0; j < gridSize; j++) {
            if (matched[i][j] == 1) {
                matchCount++;
            }
        }
    }
    
    return matchCount;
}


void removeMatches(int gridSize)
{
    for (int i = 0; i < gridSize; i++) {
        for (int j = 0; j < gridSize; j++) {
            if (matched[i][j] == 1) {
                level1Candies[i][j].type = TYPE_EMPTY;
            }
        }
    }
}

void applyGravity(int gridSize)
{
    for (int column = 0; column < gridSize; column++)
    {
        for (int row = gridSize - 1; row >= 0; row--)
        {
            if (level1Candies[row][column].type == TYPE_EMPTY)
            {
                int k = row - 1;
                while (k >= 0 && level1Candies[k][column].type == TYPE_EMPTY)
                {
                    k--;
                }
                if (k >= 0)
                {
                    level1Candies[row][column].type = level1Candies[k][column].type;
                    level1Candies[k][column].type = TYPE_EMPTY;
                }
            }
        }
    }
}


void refillBoard(int gridSize, int candyTypes)
{
    for (int i = 0; i < gridSize; i++)
    {
        for (int j = 0; j < gridSize; j++)
        {
            if (level1Candies[i][j].type == TYPE_EMPTY)
            {
                level1Candies[i][j].type = (CandyType)(rand() % candyTypes);
            }
        }
    }
}

// Function to handle single index swap (used by input handler)
void SwapCandies(int r1, int c1, int r2, int c2)
{
    CandyType temp = level1Candies[r1][c1].type;
    level1Candies[r1][c1].type = level1Candies[r2][c2].type;
    level1Candies[r2][c2].type = temp;
}

bool areAdjacent(int r1, int c1, int r2, int c2) { 
    return (std::abs(r1 - r2) + std::abs(c1 - c2) == 1); 
}

sf::Vector2f getCandyPosition(int r, int c, int gridSize, float cellSize, float gap) {
    float gridX = 550.f; float gridY = 300.f; float cellUnit = cellSize + gap;
    
    // Grid sprite is 800x900, but we use the central 800x800 for placement
    float containerWidth = 800.f; 
    float containerHeight = 900.f;

    float totalContentWidth = gridSize * cellSize + (gridSize - 1) * gap;
    float totalContentHeight = gridSize * cellSize + (gridSize - 1) * gap;

    float startX = gridX + (containerWidth - totalContentWidth) / 2.f;
    float startY = gridY + (containerHeight - totalContentHeight) / 2.f; 

    return sf::Vector2f(startX + c * cellUnit, startY + r * cellUnit);
}

// --- MAIN SFML FUNCTION ---

int main() {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    sf::RenderWindow window(sf::VideoMode(1800, 1100), "Candy Crush Clone");
    window.setFramerateLimit(60);

    // --- ASSET LOADING ---
    sf::Font font;
    if (!font.loadFromFile("assets/funsized.ttf")) std::cerr << "Failed to load funsized font\n";
    mainFont = font; // Use the loaded font for general text

    sf::Font volumeFont;
    if (!volumeFont.loadFromFile("assets/SuperAdorable-MAvyp.ttf")) std::cerr << "Failed to load volume font\n";

    sf::Font levelInsideFont;
    if (!levelInsideFont.loadFromFile("assets/DroplineRegular-Wpegz.otf")) std::cerr << "Failed to load level detail font\n";

    // Load Candy Textures
    if (!candyTextures[0].loadFromFile("assets/candy1.png")) std::cout << "Error loading candy1\n";
    if (!candyTextures[1].loadFromFile("assets/candy2.png")) std::cout << "Error loading candy2\n";
    if (!candyTextures[2].loadFromFile("assets/candy3.png")) std::cout << "Error loading candy3\n";
    if (!candyTextures[3].loadFromFile("assets/candy4.png")) std::cout << "Error loading candy4\n";
    if (!candyTextures[4].loadFromFile("assets/candy5.png")) std::cout << "Error loading candy5\n";

    // --- BACKGROUND / INTRO OBJECTS ---
    sf::Texture backgroundTexture, loadingTexture, menuBgTexture;
    backgroundTexture.loadFromFile("assets/background.jpg");
    loadingTexture.loadFromFile("assets/LoadingPage.jpg");
    menuBgTexture.loadFromFile("assets/mainBg.png");
    
    sf::Sprite background(backgroundTexture);
    background.setScale(1800.f / backgroundTexture.getSize().x, 1100.f / backgroundTexture.getSize().y);
    
    float sideWidth = (1800.f - 800.f) / 2.f;
    sf::RectangleShape leftBlur(sf::Vector2f(sideWidth, 1100));
    leftBlur.setPosition(0, 0);
    leftBlur.setFillColor(sf::Color(0, 0, 0, 150));
    sf::RectangleShape rightBlur(sf::Vector2f(sideWidth, 1100));
    rightBlur.setPosition(800 + sideWidth, 0);
    rightBlur.setFillColor(sf::Color(0, 0, 0, 150));

    sf::RectangleShape start_main(sf::Vector2f(800, 1100));
    start_main.setPosition(500, 0);
    start_main.setFillColor(sf::Color(255, 165, 0)); // Orange

    sf::Text main_text("crush\nforce\n  3.0", mainFont, 100);
    main_text.setFillColor(sf::Color(255, 255, 153));
    main_text.setPosition(700, 400);

    sf::Sprite loadingPage(loadingTexture);
    loadingPage.setScale(800.f / loadingTexture.getSize().x, 1100.f / loadingTexture.getSize().y);
    loadingPage.setPosition(500, 0);

    // --- MENU OBJECTS ---
    sf::Sprite mainBg(menuBgTexture);
    mainBg.setScale(800.f / menuBgTexture.getSize().x, 1100.f / menuBgTexture.getSize().y);
    mainBg.setPosition(500, 0);

    sf::Texture PlayBtnTexture, retrieveBtnTexture, SettingBtnTexture;
    PlayBtnTexture.loadFromFile("assets/PlayButton.png");
    retrieveBtnTexture.loadFromFile("assets/retrieveButton.png");
    SettingBtnTexture.loadFromFile("assets/SettingsButton.png");

    sf::Sprite PlayBtn(PlayBtnTexture);
    PlayBtn.setScale(300.f / PlayBtnTexture.getSize().x, 100.f / PlayBtnTexture.getSize().y);
    PlayBtn.setPosition(750, 690);

    sf::Sprite retrieveBtn(retrieveBtnTexture);
    retrieveBtn.setScale(330.f / retrieveBtnTexture.getSize().x, 100.f / retrieveBtnTexture.getSize().y);
    retrieveBtn.setPosition(735, 800);

    sf::Sprite SettingBtn(SettingBtnTexture);
    SettingBtn.setScale(70.f / SettingBtnTexture.getSize().x, 70.f / SettingBtnTexture.getSize().y);
    SettingBtn.setPosition(540, 900);

    sf::Sprite PlayBtnShadow = PlayBtn; PlayBtnShadow.setColor(sf::Color(0, 0, 0, 150)); PlayBtnShadow.setPosition(PlayBtn.getPosition().x + 5, PlayBtn.getPosition().y + 5);
    sf::Sprite retrieveBtnShadow = retrieveBtn; retrieveBtnShadow.setColor(sf::Color(0, 0, 0, 150)); retrieveBtnShadow.setPosition(retrieveBtn.getPosition().x + 5, retrieveBtn.getPosition().y + 5);
    sf::Sprite SettingBtnShadow = SettingBtn; SettingBtnShadow.setColor(sf::Color(0, 0, 0, 150)); SettingBtnShadow.setPosition(SettingBtn.getPosition().x + 5, SettingBtn.getPosition().y + 5);


    // --- SETTINGS OBJECTS (Simplified from your code) ---
    sf::Texture settingBgUpTexture, settingBgTexture, generalTexture, crossTexture;
    settingBgUpTexture.loadFromFile("assets/clouds.jpg");
    settingBgTexture.loadFromFile("assets/settingBg.jpg");
    generalTexture.loadFromFile("assets/general.png");
    crossTexture.loadFromFile("assets/cross.png");
    
    sf::Sprite settingBgUp(settingBgUpTexture); settingBgUp.setScale(800.f / settingBgUpTexture.getSize().x, 200.f / settingBgUpTexture.getSize().y); settingBgUp.setPosition(500, 0);
    sf::Sprite settingBg(settingBgTexture); settingBg.setScale(800.f / settingBgTexture.getSize().x, 900.f / settingBgTexture.getSize().y); settingBg.setPosition(500, 200);
    sf::Sprite general(generalTexture); general.setScale(800.f / generalTexture.getSize().x, 100.f / generalTexture.getSize().y); general.setPosition(500, 110);
    sf::Sprite cross(crossTexture); cross.setScale(80.f / crossTexture.getSize().x, 80.f / crossTexture.getSize().y); cross.setPosition(1150, 30);
    sf::Sprite crossShadow = cross; crossShadow.setColor(sf::Color(0, 0, 0, 120)); crossShadow.setPosition(cross.getPosition().x + 4, cross.getPosition().y + 4);

    // Volume UI
    sf::RectangleShape volumePanel(sf::Vector2f(700.f, 300.f)); volumePanel.setPosition(550, 300); volumePanel.setFillColor(sf::Color(255, 240, 250)); volumePanel.setOutlineThickness(4); volumePanel.setOutlineColor(sf::Color(255, 200, 220));
    sf::Text volumeLabel("Volume:", volumeFont, 70); volumeLabel.setFillColor(sf::Color(150, 30, 60)); volumeLabel.setPosition(580, 320);
    sf::RectangleShape volumeBar(sf::Vector2f(450.f, 14.f)); volumeBar.setFillColor(sf::Color(255, 180, 210)); volumeBar.setPosition(600, 480);
    sf::CircleShape volumeKnob(25.f); volumeKnob.setFillColor(sf::Color(20, 110, 255)); volumeKnob.setOutlineThickness(4); volumeKnob.setOutlineColor(sf::Color::White);
    float knobRadius = 25.f; volumeKnob.setRadius(knobRadius); volumeKnob.setOrigin(knobRadius, knobRadius);

    sf::RectangleShape toggleBase(sf::Vector2f(80.f, 40.f)); toggleBase.setPosition(1100, 350);
    sf::CircleShape toggleCircle(18.f); toggleCircle.setFillColor(sf::Color::White);

    // Initial volume position
    volumeKnob.setPosition(volumeBar.getPosition().x + volumeValue * volumeBar.getSize().x, volumeBar.getPosition().y + volumeBar.getSize().y / 2);
    toggleBase.setFillColor(volumeEnabled ? sf::Color(100, 230, 120) : sf::Color(220, 120, 140));
    toggleCircle.setPosition(toggleBase.getPosition().x + (volumeEnabled ? 40 : 2), toggleBase.getPosition().y + 2);

    // Music
    sf::Music backgroundMusic;
    if (!backgroundMusic.openFromFile("assets/Candy Crush Menu.ogg")) std::cerr << "Failed to load music!\n";
    backgroundMusic.setLoop(true);
    backgroundMusic.play();
    backgroundMusic.setVolume(volumeValue * 100);


    // --- LEVELS OBJECTS ---
    sf::Texture levelsBgTexture, livesBgTexture, livescandyBgTexture;
    levelsBgTexture.loadFromFile("assets/levelsBg.jpg");
    livesBgTexture.loadFromFile("assets/livesBg.png");
    livescandyBgTexture.loadFromFile("assets/candy.png");
    
    sf::Sprite levelsBg(levelsBgTexture); levelsBg.setScale(800.f / levelsBgTexture.getSize().x, 1100.f / levelsBgTexture.getSize().y); levelsBg.setPosition(500, 0);
    sf::Sprite livesBg(livesBgTexture); livesBg.setScale(300.f / livesBgTexture.getSize().x, 200.f / livesBgTexture.getSize().y); livesBg.setPosition(550, 30);
    sf::Sprite livescandyBg(livescandyBgTexture); livescandyBg.setScale(100.f / livescandyBgTexture.getSize().x, 100.f / livescandyBgTexture.getSize().y); livescandyBg.setPosition(530, 70);

    // Level UI Circles/Stars
    sf::Vector2f levelPositions[10] = {
        {850, 1010}, {975, 930}, {1050, 810}, {1000, 670}, {875, 590}, 
        {739, 520}, {785, 395}, {900, 315}, {979, 200}, {1020, 60}
    };
    sf::CircleShape levelCircles[10];
    sf::Text levelNumbers[10];
    sf::CircleShape levelStarsDisplay[10][3]; 

    for (int i = 0; i < 10; i++) {
        levelCircles[i].setRadius(45.f); levelCircles[i].setOrigin(50.f, 50.f); levelCircles[i].setPosition(levelPositions[i]);
        levelNumbers[i].setFont(mainFont); levelNumbers[i].setCharacterSize(30); levelNumbers[i].setFillColor(sf::Color::Black);
        levelNumbers[i].setString(std::to_string(i + 1)); 
        levelNumbers[i].setOrigin(levelNumbers[i].getLocalBounds().width / 2, levelNumbers[i].getLocalBounds().height / 2);
        levelNumbers[i].setPosition(levelPositions[i].x - 5, levelPositions[i].y - 10); // Center adjustment
        
        for (int j = 0; j < 3; j++) {
            levelStarsDisplay[i][j].setRadius(10.f); levelStarsDisplay[i][j].setOrigin(10.f, 10.f);
            levelStarsDisplay[i][j].setPosition(levelPositions[i].x - 30 + j * 25, levelPositions[i].y + 60);
        }
    }


    // --- LEVEL 1 GAME UI OBJECTS ---
    sf::Texture gridUpTexture, gridTexture, iconTexture;
    gridUpTexture.loadFromFile("assets/gridUp.png");
    gridTexture.loadFromFile("assets/Candygrid.jpg");
    iconTexture.loadFromFile("assets/icon.png");

    sf::Sprite gridUp(gridUpTexture); gridUp.setScale(800.f / gridUpTexture.getSize().x, 300.f / gridUpTexture.getSize().y); gridUp.setPosition(500, 0);
    sf::Sprite grid(gridTexture); grid.setScale(800.f / gridTexture.getSize().x, 900.f / gridTexture.getSize().y); grid.setPosition(500, 200);
    sf::Sprite icon(iconTexture); icon.setScale(200.f / iconTexture.getSize().x, 200.f / iconTexture.getSize().y); icon.setPosition(1050, 50);

    // Win/Fail Screen Text
    sf::Text endLevelText("", mainFont, 80);
    endLevelText.setFillColor(sf::Color(255, 220, 50));
    endLevelText.setOutlineColor(sf::Color(150, 30, 60));
    endLevelText.setOutlineThickness(5);
    endLevelText.setPosition(900, 550);

    // Initial grid setup (done when entering LEVEL1 state)
    GenerateCandyGrid(level1Candies, getGridSize(currentLevel), 5); 

    // --- MAIN GAME LOOP ---

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed) window.close();

            // --- UNIVERSAL KEYBOARD INPUT ---
            if (event.type == sf::Event::KeyPressed) {
                if (gameState == STATE_MENU && event.key.code == sf::Keyboard::S) gameState = STATE_SETTINGS;
                if (gameState == STATE_SETTINGS && event.key.code == sf::Keyboard::C) gameState = STATE_MENU;
                if (gameState == STATE_MENU && event.key.code == sf::Keyboard::P) gameState = STATE_LEVELS;
                if (gameState == STATE_LEVELS && event.key.code == sf::Keyboard::B) gameState = STATE_MENU;

                // Volume and Mute Controls (U, D, M)
                if (event.key.code == sf::Keyboard::U && volumeEnabled) {
                    volumeValue += 0.05f; if (volumeValue > 1.f) volumeValue = 1.f;
                }
                if (event.key.code == sf::Keyboard::D && volumeEnabled) {
                    volumeValue -= 0.05f; if (volumeValue < 0.f) volumeValue = 0.f;
                }
                if (event.key.code == sf::Keyboard::M) {
                    volumeEnabled = !volumeEnabled;
                    if (!volumeEnabled) { previousVolumeValue = volumeValue; volumeValue = 0.f; }
                    else { volumeValue = previousVolumeValue; }
                }

                // Level Selection (1-0 keys)
                if (gameState == STATE_LEVELS) {
                    int lvl = -1;
                    if (event.key.code >= sf::Keyboard::Num1 && event.key.code <= sf::Keyboard::Num9) {
                        lvl = event.key.code - sf::Keyboard::Num1 + 1;
                    } else if (event.key.code == sf::Keyboard::Num0) {
                        lvl = 10;
                    }
                    if (lvl != -1 && lvl <= maxUnlockedLevel) {
                        currentLevel = lvl;
                        gameState = STATE_LEVEL1;
                        restartLevel(currentLevel); // Reset and generate new grid for selected level
                    }
                }
            }

            // --- UNIVERSAL MOUSE INPUT ---
            if (event.type == sf::Event::MouseButtonPressed) {
                sf::Vector2f mousePos = window.mapPixelToCoords({event.mouseButton.x, event.mouseButton.y});

                // Handle Level Selection by Clicking
                if (gameState == STATE_LEVELS) {
                    for (int i = 0; i < 10; ++i) {
                        if (levelCircles[i].getGlobalBounds().contains(mousePos)) {
                            int lvl = i + 1;
                            if (lvl <= maxUnlockedLevel) {
                                currentLevel = lvl;
                                gameState = STATE_LEVEL1;
                                restartLevel(currentLevel); // Reset and generate new grid for selected level
                                break;
                            }
                        }
                    }
                }

                // Handle Game Play Clicks
                if (gameState == STATE_LEVEL1 && logicState == LOGIC_IDLE) {
                    int gridSize = getGridSize(currentLevel);
                    float cellSize = 75.f; float gap = 10.f;
                    
                    float totalContentWidth = gridSize * cellSize + (gridSize - 1) * gap;
                    float containerWidth = 800.f;
                    float startX = 550.f + (containerWidth - totalContentWidth) / 2.f;
                    float startY = 300.f + (900.f - totalContentWidth) / 2.f; // Approximate start Y

                    // Calculate clicked row/column
                    int clickedR = (int)((mousePos.y - startY) / (cellSize + gap));
                    int clickedC = (int)((mousePos.x - startX) / (cellSize + gap));

                    if (clickedR >= 0 && clickedR < gridSize && clickedC >= 0 && clickedC < gridSize) {
                        if (selectedR == -1) { 
                            selectedR = clickedR; selectedC = clickedC; 
                        }
                        else if (areAdjacent(selectedR, selectedC, clickedR, clickedC)) {
                            secondR = clickedR; secondC = clickedC;
                            swapRequested = true;
                            logicState = LOGIC_SWAPPING;
                        } else { 
                            selectedR = clickedR; selectedC = clickedC; 
                        }
                    } else {
                        selectedR = selectedC = -1; // Clicked outside the grid, deselect
                    }
                }
            }
        } // end pollEvent

        // --- GLOBAL UPDATES (Music/Volume UI) ---
        backgroundMusic.setVolume(volumeValue * 100.f);
        volumeKnob.setPosition(volumeBar.getPosition().x + volumeValue * volumeBar.getSize().x, volumeBar.getPosition().y + volumeBar.getSize().y / 2);
        toggleBase.setFillColor(volumeEnabled ? sf::Color(100, 230, 120) : sf::Color(220, 120, 140));
        toggleCircle.setPosition(toggleBase.getPosition().x + (volumeEnabled ? 40 : 2), toggleBase.getPosition().y + 2);

        // --- STATE TRANSITIONS AND TIMERS ---
        float t = transitionClock.getElapsedTime().asSeconds();
        if (gameState == STATE_INTRO && t > INTRO_DISPLAY_TIME + FADE_OUT_TIME + LOADING_SHOW_TIME) {
            gameState = STATE_MENU;
        }

        // Win/Fail screen timer check
        if ((gameState == STATE_WIN || gameState == STATE_FAIL) && endLevelClock.getElapsedTime().asSeconds() > END_LEVEL_SCREEN_DURATION) {
            gameState = STATE_LEVELS; // Return to level selection after message
        }

        // --- DRAWING LOGIC ---
        window.clear();
        window.draw(background);
        window.draw(leftBlur);
        window.draw(rightBlur);

        if (gameState == STATE_INTRO) 
        {
            float orangeEnd = INTRO_DISPLAY_TIME + FADE_OUT_TIME;
            if (t < orangeEnd) {
                float alpha = 255.f;
                if (t > INTRO_DISPLAY_TIME) alpha = 255.f * (1.f - (t - INTRO_DISPLAY_TIME) / FADE_OUT_TIME);
                
                // Draw Orange Screen
                start_main.setFillColor(sf::Color(255, 165, 0, (sf::Uint8)alpha));
                main_text.setFillColor(sf::Color(255, 255, 153, (sf::Uint8)alpha));
                window.draw(start_main);
                window.draw(main_text);

                // Draw Loading Screen underneath during fade-out
                if (t > INTRO_DISPLAY_TIME) {
                    float invAlpha = 255 - (sf::Uint8)alpha;
                    loadingPage.setColor(sf::Color(255, 255, 255, (sf::Uint8)invAlpha));
                    window.draw(loadingPage);
                }
            } else {
                // Draw Loading Screen fully opaque
                loadingPage.setColor(sf::Color(255, 255, 255, 255));
                window.draw(loadingPage);
            }
        }
        else if (gameState == STATE_MENU) 
        {
            window.draw(mainBg);
            window.draw(PlayBtnShadow);
            window.draw(retrieveBtnShadow);
            window.draw(SettingBtnShadow);
            window.draw(retrieveBtn);
            window.draw(PlayBtn);
            window.draw(SettingBtn);
        }
        else if (gameState == STATE_SETTINGS) 
        {
            window.draw(settingBg);
            window.draw(settingBgUp);
            window.draw(general);
            window.draw(volumePanel);
            window.draw(volumeLabel);
            window.draw(volumeBar);
            window.draw(volumeKnob);
            window.draw(toggleBase);
            window.draw(toggleCircle);
            window.draw(crossShadow);
            window.draw(cross);
            window.draw(leftBlur);
            window.draw(rightBlur);
        }
        else if (gameState == STATE_LEVELS) 
        {
            window.draw(levelsBg);
            window.draw(livesBg);
            window.draw(livescandyBg);

            sf::Text livesText("Lives : " + std::to_string(lives), levelInsideFont, 30);
            livesText.setFillColor(sf::Color::Red);
            livesText.setPosition(670, 110);
            window.draw(livesText);

            for (int i = 0; i < 10; i++) {
                // Update circle color for locked/unlocked levels
                levelCircles[i].setFillColor(i + 1 <= maxUnlockedLevel ? sf::Color(255, 200, 0) : sf::Color(100, 100, 100));
                window.draw(levelCircles[i]);
                window.draw(levelNumbers[i]);

                // Draw stars
                for (int j = 0; j < 3; j++) {
                    if (j < levelStars[i]) levelStarsDisplay[i][j].setFillColor(sf::Color::Yellow);
                    else levelStarsDisplay[i][j].setFillColor(sf::Color(100, 100, 100));
                    window.draw(levelStarsDisplay[i][j]);
                }
            }
        }
        else if (gameState == STATE_LEVEL1)
        {
            window.draw(gridUp);
            window.draw(grid);
            window.draw(icon);

            // Update UI elements based on current game state
            sf::Text starsText("Stars : " + std::to_string(currentlivestars), levelInsideFont, 30);
            starsText.setFillColor(sf::Color::Yellow); starsText.setPosition(550, 60); window.draw(starsText);

            sf::Text requirementText("Moves : " + std::to_string(currentMoves), levelInsideFont, 30);
            requirementText.setFillColor(sf::Color::Green); requirementText.setPosition(550, 90); window.draw(requirementText);
            
            sf::Text scoreDisplay("Score : " + std::to_string(score), levelInsideFont, 30);
            scoreDisplay.setFillColor(sf::Color::Red); scoreDisplay.setPosition(750, 60); window.draw(scoreDisplay);

            int gridSize = getGridSize(currentLevel);
            float cellSize = 75.f; float gap = 10.f;

            // --- GAME LOGIC STATE MACHINE UPDATE ---
            int matchCount = 0;
            switch (logicState) {
                case LOGIC_SWAPPING:
                    SwapCandies(selectedR, selectedC, secondR, secondC);
                    logicState = LOGIC_CHECKING;
                    break;
                case LOGIC_CHECKING:
                    matchCount = countMatches(gridSize);
                    if (matchCount > 0) {
                        if (swapRequested) {
                            // Deduct move ONLY here, on the first successful match after a player swap
                            currentMoves--; 
                        }
                        playLevel(matchCount * 100); // Calls playLevel which handles state transition on WIN/FAIL
                        removeMatches(gridSize);
                        logicState = LOGIC_FALLING;
                        swapRequested = false; // Player move is processed
                    } else if (swapRequested) {
                        // Swap back if no match was found after player swap
                        SwapCandies(selectedR, selectedC, secondR, secondC);
                        swapRequested = false;
                        selectedR = -1; secondR = -1;
                        logicState = LOGIC_IDLE;
                    } else {
                        // Chain finished or idle (happens during gravity/refill checks)
                        logicState = LOGIC_IDLE;
                    }
                    break;
                case LOGIC_FALLING:
                    applyGravity(gridSize);
                    logicState = LOGIC_REFILLING;
                    break;
                case LOGIC_REFILLING:
                    refillBoard(gridSize, 5);
                    logicState = LOGIC_CHECKING; // Recheck for new matches created by refill/gravity
                    break;
                case LOGIC_IDLE:
                default:
                    // Win/Lose check is mainly done in playLevel, but also here if a player stops chaining
                    if (currentMoves <= 0 && !isLevelPassedForWin()) {
                         failLevel();
                         gameState = STATE_FAIL;
                         endLevelClock.restart();
                    } 
                    swapRequested = false; // Reset request flag when truly idle
                    break;
            }

            // --- DRAW CANDIES ---
            for (int i = 0; i < gridSize; i++) {
                for (int j = 0; j < gridSize; j++) {
                    Candy& c = level1Candies[i][j];

                    if (c.type != TYPE_EMPTY) {
                        sf::Sprite candySprite(candyTextures[c.type]);

                        float cellSizeFinal = 75.f; // Use a fixed cell size for drawing consistency
                        float scaleX = cellSizeFinal / candyTextures[c.type].getSize().x;
                        float scaleY = cellSizeFinal / candyTextures[c.type].getSize().y;
                        candySprite.setScale(scaleX, scaleY);

                        sf::Vector2f pos = getCandyPosition(i, j, gridSize, cellSizeFinal, gap);
                        candySprite.setPosition(pos);

                        // Highlighting selected candy
                        if ((i == selectedR && j == selectedC)) {
                            candySprite.setColor(sf::Color(255, 255, 255, 180)); // Semi-transparent overlay
                        } else {
                            candySprite.setColor(sf::Color::White);
                        }
                        
                        window.draw(candySprite);
                    }
                }
            }
        }
        else if (gameState == STATE_WIN)
        {
            // Simple gray/blur background
            sf::RectangleShape overlay(sf::Vector2f(1800, 1100));
            overlay.setFillColor(sf::Color(0, 0, 0, 150));
            window.draw(overlay);

            // Draw Congratulations text
            endLevelText.setString("LEVEL " + std::to_string(currentLevel - 1) + " COMPLETE!\n\nCONGRATULATIONS!");
            endLevelText.setFillColor(sf::Color(255, 220, 50));
            endLevelText.setOutlineColor(sf::Color(150, 30, 60));
            endLevelText.setOrigin(endLevelText.getLocalBounds().width / 2.f, endLevelText.getLocalBounds().height / 2.f);
            window.draw(endLevelText);
        }
        else if (gameState == STATE_FAIL) // <-- NEW FAIL STATE DRAWING LOGIC
        {
            // Simple gray/blur background
            sf::RectangleShape overlay(sf::Vector2f(1800, 1100));
            overlay.setFillColor(sf::Color(0, 0, 0, 150));
            window.draw(overlay);

            // Draw Oops/Replay text
            endLevelText.setString("OOPS!\nMOVES FINISHED.\n\nREPLAY LEVEL " + std::to_string(currentLevel) + "!");
            endLevelText.setFillColor(sf::Color(255, 80, 80));
            endLevelText.setOutlineColor(sf::Color(80, 0, 0));
            endLevelText.setOrigin(endLevelText.getLocalBounds().width / 2.f, endLevelText.getLocalBounds().height / 2.f);
            window.draw(endLevelText);
        }

        window.display();
    } 

    return 0;
}